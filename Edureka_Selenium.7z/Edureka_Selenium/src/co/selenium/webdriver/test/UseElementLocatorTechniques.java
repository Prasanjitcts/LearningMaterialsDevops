package co.selenium.webdriver.test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UseElementLocatorTechniques {
	
	
	WebDriver driver;
	
	
	public void invokeBrowser(String url)
	{
		try {
			System.setProperty("webdriver.chrome.driver","E:\\Prasanjit\\chromedriver_win32\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.get(url);
		} catch (Exception e) {
			
			e.printStackTrace();
		}		
		
	}
	
	public void elementLocatorTechniquesusingYatra()
	{
		invokeBrowser("https://www.skyscanner.com");
		driver.findElement(By.xpath("//*[@id='depart-fsc-datepicker-button']")).click();
		
		
	}
	
	public void elementLocatorTechniquesusingcyclos()
	{
		invokeBrowser("https://demo.cyclos.org/#login");
		driver.findElement(By.name("principal")).sendKeys("demo");
		driver.findElement(By.name("password")).sendKeys("1234");
		driver.findElement(By.cssSelector("button.actionButton")).click();
	
		
	}
	
	
	public void  closeBrowser()
	{
		driver.close();
	}
	
public void elementlocatortechniquesusingAmazon()
{
	try {

		invokeBrowser("https://www.amazon.in/");
		//driver.findElement(By.linkText("Your Amazon.in")).click();
		//driver.navigate().back();
		//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone");
		//driver.findElement(By.className("nav-input")).click();
		//driver.findElement(By.partialLinkText("Customer")).click();
		//driver.findElement(By.xpath("//div[@id='nav-tools']/a[@id='nav-link-yourAccount']/span[1]")).click();
		//driver.findElement(By.xpath("//a[contains(@aria-label,'ELECTRONICS')]")).click();
		//driver.findElement(By.xpath("//a[starts-with(@aria-label,'Gully Boy')]")).click();
		//driver.findElement(By.xpath("//img[contains(@src,'banners1')]")).click();
		  driver.findElement(By.xpath("//img[contains(@alt,'24781775911')]")).click();
	
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	
	
}
	
	public static void main(String[] args) {
		
		UseElementLocatorTechniques obj=new UseElementLocatorTechniques();
		//obj.elementlocatortechniquesusingAmazon();
		obj.elementlocatortechniquesusingAmazon();
		
	}

}
